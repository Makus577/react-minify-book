import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';

const appState = {
    title: {
        text: 'React minify book',
        color: 'red'
    },
    content: {
        text: 'React minify book content',
        color: 'blue'
    }
}

function renderApp(appState) {
    renderTitle(appState.title);
    renderContent(appState.content);
}
function renderTitle(title) {
    const titleDOM = document.getElementById('title');
    titleDOM.innerHTML = title.text;
    titleDOM.style.color = title.color;
}
function renderContent(content) {
    const contentDOM = document.getElementById('content');
    contentDOM.innerHTML = content.text;
    contentDOM.style.color = content.color;
}
function dispath(action) {
    switch (action.type) {
        case 'UPDATE_TITLE_TEXT':
            appState.title.text = action.text;
            break;
        case 'UPDATE_TITLE_COLOR':
            appState.title.color = action.color;
            break;
        default:
            break;
    }
}
renderApp(appState);
dispath({type: 'UPDATE_TITLE_TEXT', text: '《React minify book》'});
dispath({type: 'UPDATE_TITLE_COLOR', text: 'blue'})
renderApp(appState);


function createStore (state, stateChanger) {
    const getState = () => state;
    const dispath = (action) => stateChanger(state, action);
    return { getState, dispath };
}
let appState = {
    title: {
        text:'React 小书',
        color: 'red'
    }, 
    content: {
        text: 'React.js 小书内容',
        color: 'blue'
    }
}
function stateChanger(state, action) {
    switch (action.type) {
        case 'UPDATE_TITLE_TEXT': 
            state.title.text = action.text;
            break;
        case 'UPDATE_TITLE_COLOR':
            state.title.color = action.color;
            break;
        default:
            break;
    }
}
const store = createStore(appState, stateChanger);
renderApp(store.getState());
store.dispath({type: 'UPDATE_TITLE_TEXT', text: '《React.js 小书》'})
store.dispath({type: 'UPDATE_TITLE.COLOR', color: 'blue'});
renderApp(store.getState());


function createStore(state, stateChanger) {
    const listeners = [];
    const subscribe = (listener) => listeners.push(listener);
    const getState = (state) => state;
    const dispath = (action) => {
        stateChanger(state, action);
        listeners.forEach((listener) => listener())
    }
    return { getState, dispath, subscribe }
}
const stroe = createStore(appState, stateChanger);
store.subscribe(() => renderApp(store.getState()))

// ReactDOM.render(<App />, document.getElementById('root'));
registerServiceWorker();
